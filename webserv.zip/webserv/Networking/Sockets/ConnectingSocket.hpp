
//
// Created by Brittni Ashleigh on 9/4/21.
//

#ifndef UNTITLED_CONNECTINGSOCKET_HPP
#define UNTITLED_CONNECTINGSOCKET_HPP
#include "stdio.h"
#include "SimpleSocket.hpp"

class ConnectingSocket : public SimpleSocket {
private:
public:
	ConnectingSocket(int domain, int service, int protocol,
					 int port, u_long interface);
	int connect_to_network(int sock, struct sockaddr_in address);
};


#endif //UNTITLED_CONNECTINGSOCKET_HPP
