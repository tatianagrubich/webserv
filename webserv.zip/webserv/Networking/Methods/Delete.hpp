
//
// Created by Brittni Ashleigh on 9/16/21.
//

#ifndef UNTITLED_DELETE_HPP
#define UNTITLED_DELETE_HPP
#include "../Server/BasicMethod.hpp"


class Delete : public BasicMethod{
private:
public:
	Delete(Client *client);
	void _makeResponseBody();
	void _handling();
	void _makeResponseHeader();
};

#endif //UNTITLED_DELETE_HPP
