#ifndef UTILS_CPP
#define UTILS_CPP
#include <sys/stat.h>
#include "MimeTypes.hpp"
#include "Utils.hpp"

MimeTypes types;

std::string getTypeByExtension(const std::string& ext)
{
	return types.getTypeByExtension(ext);
}

std::string getExtensionByType(const std::string& type)
{
	return types.getExtensionByType(type);
}

std::string getFileExtension(std::string filename)
{
	int extnension_pos = filename.find_last_of('.') + 1;
	return filename.substr(
			extnension_pos, filename.length() - extnension_pos
			);
}

bool isThereSuchDir(std::string full_path) {
	struct stat s;
	if( stat(full_path.c_str(),&s) == 0 )
	{
		if( s.st_mode & S_IFDIR )
			return true;
	}
	return false;
}

bool isThereSuchFile(std::string full_path) {
	struct stat s;
	if( stat(full_path.c_str(),&s) == 0 )
	{
		if( s.st_mode & S_IFREG )
			return true;
	}
	return false;
}

#endif //UTILS_CPP