#include "ConfigParser.hpp"

ConfigParser::ConfigParser(std::ifstream& fs) : _fs(fs), _lineNumber(0), _configFileName("default.conf"), _serverCount(-1), _mode(0), _isLocationParse(0), _i(0), _site(0), _location(0)
{
}

const std::string ConfigParser::_methodsList[4] = {"GET", "POST", "DELETE", "PUT"};
const std::string ConfigParser::_onOff[10] = {
	"Off",
	"On",
	"off",
	"on",
	"false",
	"true",
	"False",
	"True",
	"0",
	"1"
};

ConfigParser::~ConfigParser()
{
}

ConfigParser::ConfigParser(const ConfigParser &copy, std::ifstream& fs) : _fs(fs)
{
	operator=(copy);
}

ConfigParser &ConfigParser::operator=(const ConfigParser &copy)
{
	if (this != &copy)
	{
	}
	return *this;
}

int ConfigParser::errormsg(const std::string &error, int err)
{
	std::cout << BRED << "Error: " << BWHITE << error << " at line " << _lineNumber << " on token " << _tkns[_i] << RESET << std::endl;
	exit(err);
}

void		ConfigParser::clearLine()
{
	size_t	hash = _line.find_first_of("#");
	if (hash != std::string::npos)
		_line.erase(hash, _line.size());
	hash = _line.find_last_not_of(" \t");
	if (hash == std::string::npos)
		_line.erase(0, _line.size());
	hash = _line.find_first_of(";");
	if (hash != std::string::npos)
	{
		if (_line.find_first_not_of(" \t", hash + 1) != std::string::npos)
		{
			std::cout << BRED << "Error: " << BWHITE << "Syntax error" << " at line " << _lineNumber << RESET << std::endl;
			exit(71);
		}
		_line.erase(hash + 1, _line.size());
	}
}

void ConfigParser::splitArgs()
{
	size_t pos = 0;
	_tkns.clear();
	int	isDquoted = false;

	while ((pos = _line.find_first_not_of(" \t", pos)) != std::string::npos)
	{
		size_t del = _line.find_first_of(" \t", pos);
		if (_line[pos] == '\"')
		{
			isDquoted = true;
			del = _line.find_first_of("\"", ++pos);
			if (del == std::string::npos)
				errormsg("Check double quotes", 73);
		}
		try
		{
			_tkns.push_back(_line.substr(pos, del - pos));
		}
		catch(const std::exception& e)
		{
			errormsg("Parsing failed", 73);
		}
		pos = del + isDquoted;
		isDquoted = false;
		if (_tkns[_tkns.size() - 1].find_first_of("\"") != std::string::npos)
			errormsg("Check double quotes", 73);
	}
}

bool	ConfigParser::nextline()
{
	unsigned	len;

	if (std::getline(_fs, _line))
	{
		_lineNumber++;
		clearLine();
		len = _line.size();
		_i = 0;
		if (len == 0)
			nextline();
		else
			splitArgs();
		return true;
	}
	else
		return false;
}

void ConfigParser::checkSemicolons()
{
	size_t tknsSize = _tkns.size() - 1;
	if (_tkns[tknsSize].find_last_of("{}") == 0)
		return ;
	if (_tkns[tknsSize].find(";") == std::string::npos)
		errormsg("Syntax error", 72);
	if (_tkns[tknsSize].size() == 1)
		_tkns.pop_back();
	else
		_tkns[tknsSize].erase(_tkns[tknsSize].size() - 1);
}

int		ConfigParser::parsMethods()
{
	int	method = 0;

	while (++_i < _tkns.size())
	{
		if (_tkns[_i].find_first_of(",") != std::string::npos)
			_tkns[_i].erase(_tkns[_i].size() - 1, std::string::npos);
		for (int i = 0; i < 5; i++)
		{
			if (i < 4 && !_tkns[_i].compare(0, _tkns[_i].size(), _methodsList[i]))
			{
				if (method & 1 << i)
					return 66;
				method += 1 << i;
				break;
			}
			if (i == 3)
				return 74;
		}
	}
	_location->setMethods(method);
	return 0;
}

int	ConfigParser::parsAutoIndex()
{
	_i++;
	for (int i = 0; i < 10; i++)
		if (!_tkns[_i].compare(_onOff[i]))
			return _location->setAutoIndex(i % 2);
	return 5;
}

int ConfigParser::parsIP(int ret)
{
	if (!std::regex_match(_tkns[_i], std::regex("[.:0-9]+")))
		errormsg("Wrong IP:PORT", 75);
	return ret;
}

int ConfigParser::parsInt(int ret)
{
	if (ret)
		_i++;
	try
	{
		ret = stoi(_tkns[_i]);
		if (!std::regex_match(_tkns[_i], std::regex("[0-9]+")))
			errormsg("Unknown parameter", 76);
	}
	catch(const std::exception& so)
	{
		errormsg("Unknown parameter", 76);
	}
	return ret;
}

int	ConfigParser::parsPath(int ret, int flag)
{
	if (_tkns[_i][0] != '/' || (_tkns[_i].back() == '/') & flag)
	{
		errormsg("Check '/' in path", 69);
	}
	return ret;
}

int ConfigParser::parsRedirect()
{
	int ret = parsInt(1);
	if (!ret)
	{
		ret = _location->setReturnType(ret);
		return _location->setReturnPath("") || ret;
	}
	if (ret < 300 || ret > 308)
		return 75;
	ret = _location->setReturnType(ret);
	int flag = (_tkns.size() - _i != 2);
	if (!ret)
		ret = _location->setReturnPath(_tkns[++_i]) + flag * 2;
	return ret;
}

int ConfigParser::parsErrorList()
{
	return _location->setErrorList(parsInt(0), _tkns[++_i]);
}

int		ConfigParser::parsLocationLines()
{
	int flag = (_tkns.size() - _i != 2);
	if (_mode != 1 && _mode != 2)
		return 77;
	if (!_tkns[_i].compare("root"))
		return parsPath(_location->setRoot(_tkns[++_i]), 1);
	else if (!_tkns[_i].compare("client_body_size"))
		return _location->setClientMaxBodySize(parsInt(1));
	else if (!_tkns[_i].compare("return"))
		return parsRedirect();
	else if (!_tkns[_i].compare("methods"))
		return parsMethods();
	else if (!_tkns[_i].compare("index"))
		return _location->setIndexFiles(_tkns, &(++_i));
	else if (!_tkns[_i].compare("autoindex"))
		return parsAutoIndex();
	else if (!_tkns[_i].compare("upload"))
		return parsPath(_location->setUploadPath(_tkns[++_i]), 1);
	else if (!_tkns[_i].compare("cgi_path"))
		return parsPath(_location->setCGIPath(_tkns[++_i]), 1);
	else if (!_tkns[_i].compare("cgi"))
		return _location->setCGIExt(_tkns[++_i]) + flag * 2;
	return parsErrorList();
}

void	ConfigParser::parsLocation()
{
	_i++;
	if (_mode != 1 || _tkns[_i + 1].compare("{"))
		errormsg("Parsing failed", 78);
	_mode++;
	Location *newlocation = new Location(*_WSConfigs[_serverCount]->getSiteCommon());
	_WSConfigs[_serverCount]->addLocation(newlocation);
	parsPath(0, 0);
	newlocation->setLocation(_tkns[_i++]);
	_location = newlocation;
}

void	ConfigParser::parsServer()
{
	if (_mode != 0 || _tkns[++_i].compare("{"))
		errormsg("Parsing failed", 78);
	_mode++;
	_serverCount++;
	_site = new Site();
	try
	{
		_WSConfigs.push_back(_site);
	}
	catch(const std::exception& e)
	{
		errormsg("Parsing failed", 78);
	}
	_location = _site->getSiteCommon();
}

void	ConfigParser::closeComplex()
{
	_mode--;
	if (_mode == 0 && !_site->isPortInServerName())
		errormsg("Parsing server_name failed", 79);
	if (_mode == 0 && !_site->isParsed())
		errormsg("Necessary directives are missing", 79);
	_location = _site->getSiteCommon();
}

void		ConfigParser::parser()
{
	int		err = 0;

	while (nextline())
	{
		checkSemicolons();
		while (_i < _tkns.size())
		{
			int flag = (_tkns.size() - _i != 2);
			if (!_tkns[_i].compare("server"))
				parsServer();
			else if (!_tkns[_i].compare("listen"))
				err = parsIP(_site->setListen(_tkns[++_i]));
			else if (!_tkns[_i].compare("server_name"))
				err = _site->setServerName(_tkns[++_i]) + flag * 2;
			else if (!_tkns[_i].compare("location"))
				parsLocation();
			else if (!_tkns[_i].compare("}"))
				closeComplex();
			else
				err = parsLocationLines();
			if (err)
				errormsg("Unknown parameter", err);
			_i++;
		}
	}
}

std::vector<Site*> ConfigParser::getWSConfigs()
{
	return _WSConfigs;
}
