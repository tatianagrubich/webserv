#ifndef CONFIG_HPP
# define CONFIG_HPP
# include <iostream>
# include <fstream>
# include <unistd.h>
# include <string.h>
# include "Site.hpp"
# include <vector>
# include <cstring>
# include <cstdlib>
# include <deque>
# include <map>
# define RESET			"\033[0m"
# define BBLACK			"\033[1m\033[30m"	/* Bold Black */
# define BRED			"\033[1m\033[31m"	/* Bold Red */
# define BGREEN			"\033[1m\033[32m"	/* Bold Green */
# define BYELLOW		"\033[1m\033[33m"	/* Bold Yellow */
# define BBLUE			"\033[1m\033[34m"	/* Bold Blue */
# define BMAGENTA		"\033[1m\033[35m"	/* Bold Magenta */
# define BCYAN			"\033[1m\033[36m"	/* Bold Cyan */
# define BWHITE			"\033[1m\033[37m"	/* Bold White */

class ConfigParser
{
private:
	std::ifstream&					_fs;
	int								_lineNumber;
	std::string						_configFileName;
	int								_serverCount;
	int								_mode;
	int								_isLocationParse;
	size_t							_i;
	Site							*_site;
	Location						*_location;
	std::string						_line;
	std::vector<Site*>				_WSConfigs;
	static const std::string		_methodsList[4];
	static const std::string		_onOff[10];
	std::deque<std::string>			_tkns;
	ConfigParser();
	explicit ConfigParser(const ConfigParser &, std::ifstream&);
	ConfigParser& 		operator=(const ConfigParser &);
public:
	explicit ConfigParser(std::ifstream&);
	~ConfigParser();
	int					errormsg(const std::string&, int);
	void				clearLine();
	void				splitArgs();
	bool				nextline();
	void				checkSemicolons();
	int					parsMethods();
	int					parsAutoIndex();
	int					parsIP(int);
	int					parsInt(int);
	int					parsPath(int, int);
	int					parsRedirect();
	int					parsErrorList();
	int					parsLocationLines();
	void				parsLocation();
	void				parsServer();
	void				closeComplex();
	void				parser();
	std::vector<Site*>	getWSConfigs();
};

#endif