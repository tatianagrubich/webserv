
//
// Created by Brittni Ashleigh on 9/4/21.
//

#include "BindingSocket.hpp"

BindingSocket::BindingSocket(int domain, int service, int protocol,
							 int port, u_long interface) : SimpleSocket(
							 		domain, service, protocol, port, interface
							 		)
{
	set_connection(connect_to_network(getSD(), get_address()));
	test_connection(get_connection());
}

int BindingSocket::connect_to_network(int sock, struct sockaddr_in address) {
	return bind(sock, (struct sockaddr *)&address, sizeof(address) );
}