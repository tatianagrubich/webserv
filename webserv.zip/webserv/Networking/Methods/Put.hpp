
//
// Created by Brittni Ashleigh on 9/16/21.
//

#ifndef UNTITLED_PUT_HPP
#define UNTITLED_PUT_HPP
#include "../Server/BasicMethod.hpp"
#include <sys/stat.h>
//#include <dir.h>

class Put : public BasicMethod {
public:
	Put(Client *client);
	void _makeResponseBody();
	void _handling();
	bool saveFileToServer(std::string fullRequestedPath);
	void saveFile(std::string fullRequestedPath);
};


#endif //UNTITLED_PUT_HPP
