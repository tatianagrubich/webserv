
//
// Created by Brittni Ashleigh on 9/11/21.
//

#include "Server.hpp"

Server::Server(std::vector<Site*> WebServConfigs) {
	this->WSConfigs = WebServConfigs;
	std::vector<Site*>::iterator it;

	for (it = WebServConfigs.begin(); it < WebServConfigs.end(); it++)
		setupSite(*it);

	_init_values();
}

void Server::_init_values() {
	buffSize = 5000000;
	nfds = WSConfigs.size();
	timeout = -1;
	compress = false;
	close_conn = false;
	end_server = false;
}

int Server::isAddressAlreadyExist(int port, size_t ip)
{
//	socketConfigMap;
	std::map<int, std::vector<Site*> >::iterator it;
	Site* siteConf;

	for (it = socketConfigMap.begin(); it != socketConfigMap.end(); it++)
	{
		siteConf = it->second[0];
		if (siteConf->getIP() == ip && siteConf->getPort() == port)
		{
			return it->first;
		}
	}
	return -1;
}

void Server::setupSite(Site *siteConfig) {

	int sd = isAddressAlreadyExist(siteConfig->getPort(), siteConfig->getIP());
	if (sd < 0)
	{
		ListeningSocket siteListeningSocket(AF_INET,
											SOCK_STREAM,
											0,
											siteConfig->getPort(),
											siteConfig->getIP(),
											1000);
		sd = siteListeningSocket.getSD();
	}
	socketConfigMap[sd].push_back(siteConfig);
	struct pollfd tmp_pollfd;
	tmp_pollfd.fd = sd;
	tmp_pollfd.events = POLLIN;
	fds.push_back(tmp_pollfd);
}

void Server::launch() {
	int poll_res;
    std::cout << GREEN << "SERVER IS WORKING NOW!" << SHALLOW << std::endl;
    std::cout << GREEN << "_________________________________________________________________________________________________" << SHALLOW << std::endl;
	while (true)
	{
		poll_res = poll(fds.data(), nfds, timeout);
		_error_handler(poll_res, "poll() failed");
		int current_size = nfds;
		for (int i = 0; i < current_size; i++)
		{
			if(fds[i].revents == 0)
				continue;
            else if((fds[i].revents & POLLHUP))
            {
                _clients[fds[i].fd]->setNeedToRemove(true);
            }
            else if(fds[i].revents & POLLIN)
			{
				if (isListeningSocket(fds[i].fd))
					accepter(i);
				else
					client_socket_handler(i);
			}
            if(fds[i].revents & POLLOUT)
                sender(i);
		}
        close_connection(); // if some connection was closed
		if (end_server)
			break;
	}
}

void Server::close_connection() {
    std::vector<struct pollfd>::iterator it;
    for (it = fds.begin(); it != fds.end();)
    {
        Client *client = _clients[it->fd];
        if (client != nullptr && client->isNeedToRemove())
        {
            nfds--;
            delete client;
            _clients.erase(it->fd);
            close(it->fd);
            it = fds.erase(it);
        }
        else
            it++;
    }
}

void Server::set_compress(bool value) {
	compress = value;
}

void Server::client_socket_handler(int clientSocketIndex) {

	Client *client = _clients.find(fds[clientSocketIndex].fd)->second;
	int receive_status = receiver(client);
	if (receive_status == RequestReceived)
	{
		if (client->_requestHeader["Method"] == "GET")
			Get getMethod(client);
		else if (client->_requestHeader["Method"] == "POST")
		    Post postMethod(client);
		else if (client->_requestHeader["Method"] == "DELETE")
		    Delete deleteMethod(client);
		else if (client->_requestHeader["Method"] == "PUT")
			Put putMethod(client);
		else
		{
			client->writeErrorToBody();
			client->makeResponseHeader();
			client->combineResponseParts();
		}
	}
}

void Server::_error_handler(int rc, const char *error_desc) {
	if (rc < 0)
	{
		perror(error_desc);
		exit(EXIT_FAILURE);
	}
}

void Server::_add_new_fd(int new_sd) {
	std::cout << "  New incoming connection - " << new_sd << std::endl;
	// printf("  New incoming connection - %d\n", new_sd);

	struct pollfd tmp_pollfd;
	tmp_pollfd.fd = new_sd;
	tmp_pollfd.events = POLLIN | POLLOUT;
	fds.push_back(tmp_pollfd);
	nfds++;
}

void Server::accepter(int listenerSocketIndex) {
	std::cout << "  Listening socket is acting" << std::endl;
	// printf("  Listening socket is acting\n");

	int new_sd;
	while (true)
	{
		if (fds.size() > 49)
			std::cout << "debug";
		new_sd = accept(fds[listenerSocketIndex].fd, NULL, NULL);
		if (new_sd < 0)
			return;
		Client *client = new Client(new_sd);
        client->setSiteConf(socketConfigMap[fds[listenerSocketIndex].fd]);
        _add_new_fd(new_sd);
		_clients[new_sd] = client;

	}
}

void Server::_cacheRequest(Client *client)
{
	std::string requestPart;
	recv_res = recv(client->getSd(), buffer, buffSize - 1, 0);
    if (recv_res > 0)
    {
        buffer[recv_res] = '\0';
		requestPart = std::string(buffer, recv_res);
		client->appendRequestPart(requestPart);
    }
}

int Server::receiver(Client *client)
{
	_cacheRequest(client);
	if (!client->getIsHeaderHandled())
	{
    	client->_retrieveHeader();
		if (!client->getIsHeaderHandled())
			return RequestNotReceivedYet;
	}

    std::string requestMethod = client->_requestHeader["Method"];
	if (requestMethod == "POST" || requestMethod == "PUT")
	{
		if (client->isChunked())
		{
			client->_retrieveChunkedBody();
		}
		else
			client->_retrieveSolidBody();
	}
	else
		return RequestReceived;
	if (client->getIsBodyHandled())
		return RequestReceived;
	return RequestNotReceivedYet;
}

void Server::handler()
{
	std::cout << buffer << std::endl;
}

void Server::responder()
{
	write(newSocket, "TEXTTEXT", 8);
	close(newSocket);
}

bool Server::isListeningSocket(int sd) {
	std::map<int, std::vector<Site*> >::iterator it;
	for (it = socketConfigMap.begin(); it != socketConfigMap.end(); it++)
	{
		if (it->first == sd)
			return true;
	}
	return false;
}

void Server::sender(int clientSocketIndex) {
    Client *client = _clients.find(fds[clientSocketIndex].fd)->second;
    if (client->haveDataToSend())
    {
        client->sendResponse();
        if (!client->haveDataToSend())
        {
			if (!client->isNeedToRemove())
				client->reset();
		}
    }
}


