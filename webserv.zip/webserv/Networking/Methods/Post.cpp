
//
// Created by Brittni Ashleigh on 9/16/21.
//

#include "Post.hpp"

Post::Post(Client *client) : BasicMethod(client){
	_makeResponse();
}


void Post::_makeResponseBody()
{
	std::string fullRequestedPath = _getFullRequestedPath(client->location);
	std::cout << RED << "FULL REQ PATH: " << fullRequestedPath << "\n"<< SHALLOW << std::endl;
	//check if request body length is 0
	if(client->_requestBody.length() == 0)
	{
		client->setStatusCode(204);
		return;
	}
	//check if request body length more than client max body size
	if(client->_requestBody.length() > (unsigned long)client->location->getClientMaxBodySize())
	{
		client->setStatusCode(413);
		return;
	}
	if(fullRequestedPath.back() != '/')
	{
//	std::cout << BWHITE << fullRequestedPath << SHALLOW << std::endl;
		saveFileToServer(fullRequestedPath);
	}
	else
	{
		client->setStatusCode(200);

		return;
	}
	uriIsFile(fullRequestedPath);
}

void Post::saveFile(std::string fullRequestedPath) {
	std::ofstream ofs;
	ofs.open(fullRequestedPath, std::ofstream::out | std::ofstream::binary);
	ofs.write(client->_requestBody.c_str(), client->_requestBody.length());
	ofs.close();
}


bool Post::saveFileToServer(std::string fullRequestedPath) {

	std::size_t found = fullRequestedPath.find_last_of("/\\");
	std::string fullRequestedPathDir = fullRequestedPath.substr(0,found);
	std::string nameOfFile = fullRequestedPath.substr(found+1);
	fullRequestedPath = fullRequestedPathDir + "/" + nameOfFile;
	//check if path is exist
	if (isThereSuchDir(fullRequestedPathDir))
	{
		size_t headerEndPosition = client->_requestBody.find(EMPTY_LINE);
		if (headerEndPosition == std::string::npos)
		{
			saveFile(fullRequestedPath);
			return true;
		}
		std::string _bodyHeader = client->_requestBody.substr(0, headerEndPosition + 2);
		client->_requestBody = client->_requestBody.substr(headerEndPosition + 4,client->_requestBody.length() - (headerEndPosition + 4));
		size_t pos = _bodyHeader.find("filename=\"") + 10;
		nameOfFile = "/" + _bodyHeader.substr(pos, _bodyHeader.find_first_of("\"", pos + 1) - pos);
		fullRequestedPath = fullRequestedPathDir + client->location->getUploadPath() + nameOfFile;
		saveFile(fullRequestedPath);

		return true;
	}
	//if path is not exist
	client->setStatusCode(400);
	client->writeErrorToBody();
	return false;
}

void Post::_handling()
{
}
