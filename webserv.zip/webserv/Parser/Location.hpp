#ifndef LOCATION_HPP
# define LOCATION_HPP
# include <iostream>
# include <vector>
# include <cstring>
# include <cstdlib>
# include <unistd.h>
# include <string.h>
# include <stdio.h>
# include <deque>
# include <regex>
# include <map>
# define RESET			"\033[0m"
# define BBLACK			"\033[1m\033[30m"	/* Bold Black */
# define BRED			"\033[1m\033[31m"	/* Bold Red */
# define BGREEN			"\033[1m\033[32m"	/* Bold Green */
# define BYELLOW		"\033[1m\033[33m"	/* Bold Yellow */
# define BBLUE			"\033[1m\033[34m"	/* Bold Blue */
# define BMAGENTA		"\033[1m\033[35m"	/* Bold Magenta */
# define BCYAN			"\033[1m\033[36m"	/* Bold Cyan */
# define BWHITE			"\033[1m\033[37m"	/* Bold White */

typedef std::map<int, std::string>	errMap;

class Location
{
private:
	std::string					_location;
	std::string					_root;
	int							_clientMaxBodySize;
	int							_methods;
	bool						_isGet;
	bool						_isPost;
	bool						_isDelete;
	bool						_isPut;
	bool						_autoIndex;
	int							_ret;
	std::string					_returnPath;
	std::string					_uploadPath;
	std::string					_CGIPath;
	std::string					_CGIExt;
	std::vector<std::string>	_indexFiles;
	int							_lParsed;
	int							_errParsed[10];
	errMap						_errList;
public:
	Location();
	~Location();
	Location(const Location &);
	Location&					operator=(const Location &);
	/* SETTERS */
	void						setLocation(const std::string);
	int							setRoot(const std::string);
	int							setClientMaxBodySize(size_t);
	int							setMethods(int);
	int							setAutoIndex(const bool);
	int							setReturnType(int);
	int							setReturnPath(const std::string);
	int							setUploadPath(const std::string);
	int							setCGIPath(const std::string);
	int							setCGIExt(const std::string);
	int							setIndexFiles(const std::deque<std::string>, size_t *);
	int							setErrorList(const int, const std::string);
	/* GETTERS */
	std::string					getLocation() const;
	std::string					getRoot() const;
	int							getClientMaxBodySize() const;
	bool						isGet() const;
	bool						isPost() const;
	bool						isDelete() const;
	bool						isPut() const;
	bool						getAutoIndex() const;
	int							getReturn() const;
	std::string					getReturnPath() const;
	std::string					getUploadPath() const;
	std::string					getCGIPath() const;
	std::string 				getCGIExt() const;
	std::vector<std::string>	getIndexFiles() const;
	errMap						getErrorList() const;
	bool						isMatchWithUri(std::string requestUri);
	void						getAll(std::string) const;

	int getReturn();
};

#endif