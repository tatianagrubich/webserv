
//
// Created by Brittni Ashleigh on 9/16/21.
//

#ifndef UNTITLED_POST_HPP
#define UNTITLED_POST_HPP
#include "../Server/BasicMethod.hpp"
#include <sys/stat.h>

class Post : public BasicMethod {
private:
    std::string _body;
public:
	Post(Client *client);
	void _makeResponseBody();
	void _handling();

	bool saveFileToServer(std::string fullRequestedPath);
	void saveFile(std::string fullRequestedPath);
};

#endif //UNTITLED_POST_HPP
