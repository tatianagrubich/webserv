
//
// Created by Brittni Ashleigh on 9/10/21.
//

#ifndef UNTITLED_BASICMETHOD_HPP
#define UNTITLED_BASICMETHOD_HPP
#include <iostream>
#include <string>
#include <unistd.h>     //for getcwd
#include <sys/param.h>  //for maxpathlen
#include "vector"
#include <dirent.h>
#include <map>
#include <sys/socket.h>
#include <sys/param.h>
#include <unistd.h>
#include "../../Parser/Site.hpp"
#include "Client.hpp"
#include "../../Utils/Utils.hpp"
#include <cstdio>//для удаления файлов

#define BLUE "\033[1;34m"
#define GREEN "\033[1;32m"
#define BGBLUE "\033[44m"
#define RED "\033[1;31m"
#define YELLOW "\033[0;33m"
#define SHALLOW "\033[0m"

#define EMPTY_LINE "\r\n\r\n"

class BasicMethod {
protected:

	Client *client;

	virtual void _handling() = 0;
	virtual void _makeResponseBody() = 0;
	void _makeResponse();
	bool isCGI;
    char *arrayEnvForCGI;
    std::vector<std::string> vectorOfEnvs;

	std::string fullRequestedPath;
	std::string _getFullRequestedPath(Location* location);

	std::map <int, std::string> statusCodesMap;

	bool uriIsFile(std::string path);
    void addEnv();
    void addEnvToVector(std::string fullName);
    std::string strToupper(std::string name);
//    char *strToupper(std::string name);
    void printEnvForCgi(char *key);
    void printAllExistingEnvForCgi();
    void makeAllEnvForCgi(std::string &file);
public:
	BasicMethod(Client *client);
    void _cgi(std::string &file);
};

#endif //UNTITLED_BASICMETHOD_HPP
