
//
// Created by Brittni Ashleigh on 9/11/21.
//

#ifndef UNTITLED_SERVER_HPP
#define UNTITLED_SERVER_HPP

#include "vector"
#include "../../Parser/Site.hpp"
#include "../Methods/Get.hpp"
#include "Client.hpp"
#include "../Methods/Post.hpp"
#include "../Sockets/ListeningSocket.hpp"
#include "../Methods/Post.hpp"
#include "../Methods/Delete.hpp"
#include "../Methods/Put.hpp"

#define RequestReceived 1
#define RequestNotReceivedYet 0
#define ErrorHappened -1


class Server {
private:
	std::vector<struct pollfd> fds;
	int nfds;
	std::map< int, Client* > _clients;
	std::map< int, std::vector<Site*> > socketConfigMap;

	bool compress;
	int recv_res;

	void accepter(int listenerSocketIndex);
	int receiver(Client *client);
	void client_socket_handler(int);


	int newSocket;
	char buffer[5000000];
	int buffSize;

	int timeout;
	std::vector<Site*> WSConfigs;

	bool end_server;
	bool close_conn;

	void handler();
	void responder();

	void _add_new_fd(int fd);
	void _error_handler(int rc, const char *error_desc);
	bool isListeningSocket(int sd);
	void _init_values();
    void _cacheRequest(Client *client);
public:
	void close_connection();
	void set_compress(bool value);

	void setupSite(Site *siteConfig);
	void launch();
	Server(std::vector<Site*> WebServConfigs);


    void sender(int i);

	int isAddressAlreadyExist(int port, size_t ip);
};


#endif //UNTITLED_SERVER_HPP
