
//
// Created by Brittni Ashleigh on 9/16/21.
//

#include "Get.hpp"

Get::Get(Client *client) : BasicMethod(client) {
	_makeResponse();
	}


void Get::_makeResponseBody()
{
	std::string fullRequestedPath = _getFullRequestedPath(client->location);
	std::cout << RED << "FULL REQ PATH: " << fullRequestedPath << "\n"<< SHALLOW << std::endl;
	if (uriIsFile(fullRequestedPath))
		return;
	if (uriIsDir(client->location))
		return;
	client->setStatusCode(404);
}

void Get::_handling() {

}
bool Get::uriIsDir(Location *location) {
	if (isThereSuchDir(fullRequestedPath))
	{
		std::vector<std::string> indexFiles = location->getIndexFiles();
		if (!indexFiles.empty())
		{
			std::vector<std::string>::iterator it;
			for (it = indexFiles.begin(); it < indexFiles.end(); it++)
			{
				if (uriIsFile(fullRequestedPath + "/" + (*it)))
					return true;
			}
		}
		if (location->getAutoIndex())
		{
			client->autoindex(fullRequestedPath);
			if (client->isErrorHappened())
				client->writeErrorToBody();
			return true;
		}
	}
	return false;
}

bool Get::uriIsFile(std::string path) {
	if (isThereSuchFile(path))
	{
		std::string ext = getFileExtension(path);
		client->setFileToSend(path);
		return true;
	}
	return false;
}