#include "Site.hpp"

Site::Site() : _listen("listen"),
	_serverName(""),
	_IP(0),
	_port(0),
	_locCount(0),
	_sParsed(0)
{
	_siteCommon = new Location();
}

Site::~Site()
{
	delete _siteCommon;
}

Site::Site(const Site &copy)
{
	operator=(copy);
}

Site	&Site::operator=(const Site &copy)
{
	if (this != &copy)
	{
		_listen = copy._listen;
		_serverName = copy._serverName;
		_IP = copy._IP;
		_port = copy._port;
		_locCount = copy._locCount;
		_sParsed = 0;
		*_siteCommon = *copy._siteCommon;
		_locations = copy._locations;
	}
	return *this;
}

int	Site::addLocation(Location *location)
{
	try
	{
		_locations.push_back(location);
		_locCount = _locations.size();
	}
	catch(const std::exception& e)
	{
		return 61;
	}
	return 0;
}

int	Site::setListen(std::string listen)
{
	size_t	s = listen.find(':');

	if (_sParsed & 1)
		return 66;
	_listen = listen;
	try
	{
		if (s == std::string::npos)
			_port = stoi(_listen);
		else
		{
			_port = stoi(_listen.substr(s + 1));
			// inet_pton(AF_INET, listen.substr(0, s).c_str(), &_IP);
			_IP = inet_addr(listen.substr(0, s).c_str());
		}
	}
	catch(const std::exception& so)
	{
		return 62;
	}
	if (_IP == 4294967295 || _port > 65535)
		return 63;
	_sParsed += 1;
	return 0;
}

int	Site::setServerName(std::string servername)
{
	if (_sParsed & 2)
		return 66;
	_serverName = servername;
	_sParsed += 2;
	return 0;
}

const std::string &Site::getListen() const
{
    return _listen;
}

size_t Site::getIP() const
{
	return _IP;
}

int Site::getPort() const
{
	return _port;
}

std::string	Site::getServerName() const
{
	return _serverName;
}

Location	*Site::getSiteCommon() const 
{
	return _siteCommon;
}

Location	*Site::getLocation(int nr) const
{
	return _locations[nr];
}

int	Site::getLocationCount() const
{
	return _locCount;
}

std::vector<Location *> Site::getLocations() const
{
	return _locations;
}

void	Site::getAll(int n) const
{
	std::cout << BRED << "Server: " << n + 1 << std::endl;\
	std::cout << " Listen:\t" << _listen << std::endl;
	std::cout << " IP:\t\t" << _IP << std::endl;
	std::cout << " Port:\t\t" << _port << std::endl;
	std::cout << " Server Name: \t" << _serverName << std::endl;
	std::cout << BCYAN << " Location Common ";
	_siteCommon->getAll(BCYAN);
	for (int i = 0; i < _locCount; i++)
	{
		std::cout << BGREEN << " Location " << i;
		_locations[i]->getAll(BGREEN);
	}
}

bool	Site::isPortInServerName()
{
	if (_port == 80)
		return true;
	std::string port = ":" + std::to_string(_port);
	if (_serverName.find(port) == std::string::npos)
	{
		if (_serverName.find(":") != std::string::npos)
			return false;
		_serverName += port;
	}
	return true;
}

bool	Site::isParsed() const
{
	if (_sParsed == 3)
		return true;
	return false;
}
