
//
// Created by Brittni Ashleigh on 9/4/21.
//

#include "ConnectingSocket.hpp"

ConnectingSocket::ConnectingSocket(int domain, int service, int protocol,
								   int port, u_long interface):
					SimpleSocket(domain, service, protocol,	port, interface)
{
	set_connection(connect_to_network(getSD(), get_address()));
	test_connection(get_connection());
}

int ConnectingSocket::connect_to_network(int sock, struct sockaddr_in address) {
	return connect(sock, (struct sockaddr *)&address, sizeof(address));
}