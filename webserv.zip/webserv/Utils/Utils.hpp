#ifndef UTILS_HPP
#define UTILS_HPP
#include <sys/stat.h>
#include "MimeTypes.hpp"


std::string getTypeByExtension(const std::string& ext);

std::string getExtensionByType(const std::string& type);

std::string getFileExtension(std::string filename);

bool isThereSuchDir(std::string full_path);

bool isThereSuchFile(std::string full_path);

#endif //UTILS_HPP