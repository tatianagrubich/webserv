
//
// Created by Brittni Ashleigh on 9/16/21.
//

#include "Client.hpp"
#include "BasicMethod.hpp"

Client::Client(int sd) : _sd(sd)
{
	reset();
}

std::string Client::checkForSpace(std::string str)
{
    size_t position = 0;
    for ( position = str.find("%20"); position != std::string::npos; position = str.find("%20",position) )
    {
        str.replace(position ,3, " ");
    }
    return str;
}

void Client::parseHeader(std::string buf)
{
    std::cout << YELLOW << "____________________\n" <<"REQUEST HEADER: \n"<< "____________________\n" << SHALLOW << std::endl;
    std::cout << YELLOW << buf << SHALLOW << std::endl;
	std::stringstream _buf(buf);
	std::vector<std::string> dataTmp;

	//делю весь поток на строчки и записываю во временный вектор dataTmp
	size_t i = 0;
    std::string line;
    while(std::getline(_buf, line, '\n'))
	{
		dataTmp.push_back(line);
		i++;
	}
	std::cout << std::endl;
	//делю первую строку из dataTmp на слова и записываю в вектор временный DataFirstLine
	std::istringstream temp(dataTmp[0]);
	int j = 0;
	std::vector<std::string> dataFirstLineTmp;
	while(std::getline(temp, line, ' '))
	{
		dataFirstLineTmp.push_back(line);
		j++;
	}
    //записываю метод, URL и Protocol в map класса _requestHeader
    _requestHeader.insert (std::pair<std::string,std::string>("Method", trim(dataFirstLineTmp[0])));
	std::string tempUri = checkForSpace(trim(dataFirstLineTmp[1]));
    std::cout << RED << tempUri << SHALLOW << std::endl;
    _requestHeader.insert (std::pair<std::string,std::string>("URI", tempUri));
    std::string protocol = std::string(dataFirstLineTmp[2]);
    _requestHeader.insert (std::pair<std::string,std::string>("Protocol", trim(protocol)));
    i = 1;
    // Делю остальные строчки на ключ и значение и записываю в map класса _requestHeader
    while(i < dataTmp.size() && dataTmp[i].compare("")!= 0)
    {
        std::istringstream tempStream(dataTmp[i]);
        std::vector <std::string> tempVector;
        for(std::string line; std::getline(tempStream, line, ':'); )
        {
            tempVector.push_back(line);
        }
        if (tempVector.size() == 2)
        {
            std::string trim_res = trim(tempVector[1]);
            _requestHeader.insert (std::pair<std::string,std::string>(tempVector[0], trim_res));

        }
        if (tempVector.size() == 3)
        {
            if(tempVector[0].compare("Host") == 0)
            {
                tempVector[1] = tempVector[1] + ":" + tempVector[2];
                _requestHeader.insert (std::pair<std::string,std::string>(tempVector[0], trim(tempVector[1])));
            }
        }
        tempVector.clear();
        i++;
    }
}

void Client::setIsHeaderHandled(bool isHeaderHandled) {
	this->_isHeaderHandled = isHeaderHandled;
}

void Client::setIsBodyHandled(bool isBodyHandled) {
	this->_isBodyHandled = isBodyHandled;
}

bool Client::getIsHeaderHandled() const {
	return _isHeaderHandled;
}

bool Client::getIsBodyHandled() const {
	return _isBodyHandled;
}

void Client::reset() {
	_isHeaderHandled = false;
	_isBodyHandled = false;
	rawRequest = "";
	statusCode = 200;

	_requestHeader = std::map <std::string, std::string>();
	_requestBody = std::string();
	responseBody.str("");
	responseHeader.str("");
	finalResponse = std::vector<char>();

	_responseContentLen = 0;
	_responseContentType = std::string();
	_needToRemove = false;
}

int Client::getSd() {
	return _sd;
}

Client::Client() {
}

void Client::setStatusCode(int statusCode) {
	this->statusCode = statusCode;
}

Site *Client::chooseSiteConf(std::vector<Site *> siteConfsVector)
{
	std::vector<Site *>::iterator it;
	for (it = siteConfsVector.begin(); it != siteConfsVector.end(); it++)
	{
		std::string s1 = (*it)->getServerName();
		std::string s2 = _requestHeader["Host"];

		if ((*it)->getServerName() == _requestHeader["Host"])
		{
			return *it;
		}
	}
	return siteConfsVector[0];
}

Location *Client::chooseLocation() {
	std::vector<Location*>::iterator it;
	siteConf = chooseSiteConf(siteConfsVector);
//	if (siteConf == NULL)
//		return NULL;
	std::vector<Location*> locations = siteConf->getLocations();

	for (it = locations.begin(); it < locations.end(); it++)
	{
		if ((*it)->isMatchWithUri(_requestHeader.find("URI")->second))
			return (*it);
	}
	return NULL;
}

void Client::headerValidation() {
	if (_requestHeader["Protocol"] != "HTTP/1.1")
		return setStatusCode(505);
	if (_requestHeader["Method"] != "POST" &&
		_requestHeader["Method"] != "GET" &&
		_requestHeader["Method"] != "DELETE" &&
		_requestHeader["Method"] != "PUT")
		return setStatusCode(405);
	location = chooseLocation();

	if (location == NULL)
		return setStatusCode(404);
	if (location->getReturnPath() != std::string(""))
		return setStatusCode(location->getReturn());
	if (_requestHeader["Method"] == "PUT" && !location->isPut() )
		return setStatusCode(405);
	else if (_requestHeader["Method"] == "POST" && !location->isPost() )
		return setStatusCode(405);
}

int Client::getStatusCode() {
	return statusCode;
}

bool Client::isErrorHappened() {
	if (int(statusCode / 100) == 2)
		return false;
	return true;
}

std::string Client::trimStr(std::string toTrim) {
	std::string::size_type begin = toTrim.find_first_not_of("\r");
	std::string::size_type end   = toTrim.find_last_not_of("\r");
	std::string trimmed = toTrim.substr(begin, end-begin + 1);
	return trimmed;
}

void Client::setSiteConf(std::vector<Site *> siteConfsVector) {

	this->siteConfsVector = siteConfsVector;
}

// trim from end of string (right)
std::string Client::rtrim(std::string s, const char* t)
{
	s.erase(s.find_last_not_of(t) + 1);
	return s;
}

// trim from beginning of string (left)
std::string Client::ltrim(std::string s, const char* t)
{
	s.erase(0, s.find_first_not_of(t));
	return s;
}

// trim from both ends of string (right then left)
std::string Client::trim(std::string s)
{
	const char* ws = " \t\n\r\f\v";
	return ltrim(rtrim(s, ws), ws);
}

void Client::setPollConf(struct pollfd *pollConf) {
    this->pollConf = pollConf;
}

void Client::setEvents(short flags) {

    pollConf->events = flags;
}

void Client::_retrieveHeader() {
	int headerEndPosition = rawRequest.find(EMPTY_LINE);
	if (headerEndPosition == (int)std::string::npos)
		return;
	parseHeader(rawRequest.substr(0, headerEndPosition + 2));
	_isHeaderHandled = true;
	rawRequest = rawRequest.substr(headerEndPosition + 4,
								   rawRequest.length() - (headerEndPosition + 4));
	headerValidation();
}

void Client::_retrieveSolidBody() {
	_request_header_it = _requestHeader.find("Content-Length");
	if (_request_header_it == _requestHeader.end())
		_request_header_it = _requestHeader.find("content-length");
	std::string contentLen = _request_header_it->second;
	if (!contentLen.empty())
	{
		_requestBody = rawRequest;
if ((int)_requestBody.length() >= std::stoi(contentLen))
		{
			_requestBody = _requestBody.substr(0, std::stoi(contentLen));
			_isBodyHandled = true;
		}
	}
	else
	{
		_isBodyHandled = true;
	}
}

void Client::_retrieveChunkedBody() {
	size_t start;
	std::size_t chunkSizePosition = rawRequest.find("\r\n");
	while(	chunkSizePosition != std::string::npos &&
			chunkSizePosition != rawRequest.rfind("\r\n"))
	{
		start = 0;
		std::string hexSize(rawRequest, start, chunkSizePosition - start);
		long long int sizeOfChunk = strtol(hexSize.c_str(), NULL, 16);
		if (sizeOfChunk == 0)
		{
			_isBodyHandled = true;
			return ;
		}
		start = chunkSizePosition + 2;
		//записываем chunk из requestBody длиной sizeOfChunk
		std::string chunk = rawRequest.substr(start, sizeOfChunk);
		//добавляем ко всем чанкам
		_requestBody += chunk;
		start += sizeOfChunk;
		start += 2;
		rawRequest = rawRequest.substr(start);
		chunkSizePosition = rawRequest.find("\r\n");
	}
}

void Client::appendRequestPart(std::string & requestPart) {
	rawRequest = rawRequest + requestPart;
}

void Client::appendResponseBody(std::stringstream & responseBodyPart) {
	responseBody << responseBodyPart;
	_responseContentLen = _responseContentLen + responseBodyPart.str().length();
}

void Client::appendResponseBody(std::string  responseBodyPart) {
	responseBody << responseBodyPart;
	_responseContentLen = _responseContentLen + responseBodyPart.length();
}

void Client::appendResponseBody(std::ifstream & responseBodyPart) {
	responseBody << responseBodyPart.rdbuf();
}

void Client::appendResponseHeader(std::string responseHeaderPart) {
	responseHeader << responseHeaderPart;
}

void Client::sendResponse() {
	char *bufToSend = finalResponse.data();
	int sent_bytes_n = send(_sd, bufToSend, finalResponse.size(), 0);
	if (sent_bytes_n < 0)
	{
		return;
	}
	_cutResponse(sent_bytes_n);
}

bool Client::haveDataToSend() {
	if (finalResponse.size() > 0 || _fileToSend.is_open())
		return true;
	return false;
}

void Client::setFileToSend(std::string fileToSend) {
	_fileToSend.open(fileToSend,std::ifstream::ate | std::ifstream::binary);
	if (_fileToSend.is_open())
	{
		_responseContentLen = _fileToSend.tellg();
		_fileToSend.seekg(0, _fileToSend.beg);
		_responseContentType = getTypeByExtension(
				fileToSend.substr(fileToSend.find_last_of(".") + 1)
				);
	}
}

void Client::_cutResponse(int start) {
	finalResponse.erase(finalResponse.begin(), finalResponse.begin() + start);
}

bool Client::isNeedToRemove() {
	_request_header_it = _requestHeader.find("Connection");
	if (_request_header_it != _requestHeader.end() &&
		_request_header_it->second == std::string("close"))
		return true;
	return _needToRemove;
}

void Client::setNeedToRemove(bool value) {
	_needToRemove = value;
}

int Client::getResponseContentLen() {
	return _responseContentLen;
}

void Client::combineResponseParts() {
	std::stringstream tmp;
	tmp << responseHeader.str();

	if (_fileToSend.is_open())
	{
		tmp << _fileToSend.rdbuf();
		_fileToSend.close();
	}
	else
	{
		tmp << responseBody.str();
	}

	std::string st = tmp.str();
	finalResponse = std::vector<char>(st.begin(),
									  st.end());
}

void Client::autoindex(std::string fullRequestedPath)
{
	DIR *dir; // pointer to directory
	struct dirent *entry; // all stuff in the directory
	dir = opendir(fullRequestedPath.c_str());
	//Make a body
	if (!dir)
	{
		setStatusCode(403);
		return;
	}
	responseBody << ("<!DOCTYPE html>\n"
							   "<html>\n"
							   "<head>\n"
							   "   <title>  List of files </title>\n"
							   "   <style>h1 {font-size: 200%;\n"
							   "   font-family: Verdana, Arial, Helvetica, sans-serif;\n"
							   "   color: #333366;}\n"
							   "   a {font-size: 100%;"
							   "   font-family: Verdana, Arial, Helvetica, sans-serif;\n"
							   "   color: #333366;}\n"
							   "   li :hover{font-size: 100%;"
							   "   font-family: Verdana, Arial, Helvetica, sans-serif;\n"
							   "   color: #ba2200;}\n"
							   "   li :active{font-size: 100%;"
							   "   font-family: Verdana, Arial, Helvetica, sans-serif;\n"
							   "   color: #918e00;}\n"
							   "<style>footer {\n"
							   "    position: fixed;\n"
							   "    color: #333366;}\n"
							   "    left: 0; bottom: 0;\n"
							   "   color: #333366;}\n"
							   "</style>\n"
							   "</head>\n"
							   "<body>\n"
							   "<h1 align=\"center\"> List of files</h1>");
	while ( (entry = readdir(dir)) != NULL)
	{
		responseBody << ("<li align=\"center\">"
								   "<a href =\"http://"
								   + _requestHeader["Host"]
								   + _requestHeader["URI"]
								   + "/" + entry->d_name + "\""
								   + ">" + entry->d_name
								   + "</a></li><br>");
	}
	closedir(dir);

	responseBody << ("<footer>\n"
					"&copy;    Basheleig   Cmarsha     Srickard    2021\n"
					"</footer>\n"
					"</body>\n"
					"</html>\n"
					);
	_responseContentType = getTypeByExtension("html");
	_responseContentLen = responseBody.str().length();
}

std::string Client::getResponseContentType() {
	return _responseContentType;
}

void Client::writeErrorToBody() {
    std::stringstream errorFile;
    //    while(1);
    if(location)
    {
        std::map<int, std::string>	_errList = location->getErrorList();
        errorFile << _errList[statusCode];
    }
    else
        errorFile << siteConf->getSiteCommon()->getErrorList()[404]; //"Networking/HTML/Errors/404.html";
    setFileToSend(errorFile.str());
}


void Client::makeResponseHeader() {
	responseHeader << "HTTP/1.1 "
				   << statusCode << "\n";
	if (statusCode / 100 == 3)
	{
		responseHeader << "Location: " <<  location->getReturnPath();
	}
	else
	{
		responseHeader << "Content-Type: " << _responseContentType << "\n"
					   << "server_name: " << siteConf->getServerName() << "\n"
					   << "Content-Length: " << _responseContentLen;
	}
	responseHeader << "\r\n\r\n";
}

bool Client::isChunked() {
	_request_header_it = _requestHeader.find("Transfer-Encoding");

	if (_request_header_it != _requestHeader.end() &&
	(_request_header_it->second).compare("chunked") == 0)
		return true;
	return false;
}
