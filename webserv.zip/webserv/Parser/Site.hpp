#ifndef WEBSERV_HPP
# define WEBSERV_HPP
# include <iostream>
# include <fstream>
# include "Location.hpp"
# include <netinet/in.h>
# include <sys/socket.h>
# include <arpa/inet.h>
# include <cstdlib>
# include <map>
# include <vector>

class Site
{
private:
	std::string				_listen;
	std::string				_serverName;
	size_t					_IP;
	int						_port;
	int						_locCount;
	int						_sParsed;
	Location				*_siteCommon;
	std::vector<Location*>	_locations;
public:
	Site();
	~Site();
	Site(const Site &);
	Site& 					operator=(const Site &);
	int						addLocation(Location *);
	int						setListen(std::string);
	int						setServerName(std::string);
    const std::string		&getListen() const;
	size_t					getIP() const;
	int						getPort() const;
	std::string				getServerName() const;
	Location				*getSiteCommon() const;
	Location				*getLocation(int) const;
	int						getLocationCount() const;
	std::vector<Location*>	getLocations() const;
	void					getAll(int) const;
	bool					isPortInServerName();
	bool					isParsed() const;
};

#endif