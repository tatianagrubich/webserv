
//
// Created by Brittni Ashleigh on 9/4/21.
//

#ifndef UNTITLED_LISTENINGSOCKET_HPP
#define UNTITLED_LISTENINGSOCKET_HPP
#include "BindingSocket.hpp"

class ListeningSocket : public BindingSocket {
private:
	int backlog;
	int listening;
public:
	ListeningSocket(int domain, int service, int protocol,
					int port, u_long interface, int bklg);
	void start_listening();
};


#endif //UNTITLED_LISTENINGSOCKET_HPP
