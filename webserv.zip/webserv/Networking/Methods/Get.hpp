
//
// Created by Brittni Ashleigh on 9/16/21.
//

#ifndef UNTITLED_GET_HPP
#define UNTITLED_GET_HPP
#include "../Server/BasicMethod.hpp"
#include "../Server/Client.hpp"
#include <iostream>
#include <cstdlib>

class Get : public BasicMethod {
private:
public:
	Get(Client *client);
	void _makeResponseBody();
	void _handling();
    bool uriIsDir(Location *location);
	bool uriIsFile(std::string path);
};


#endif //UNTITLED_GET_HPP
