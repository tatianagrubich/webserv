#include "Location.hpp"

Location::Location() : _location("location is nothing"),
	_root(""),
	_clientMaxBodySize(1),
	_methods(1),
	_isGet(true),
	_isPost(false),
	_isDelete(false),
	_isPut(false),
	_autoIndex(false),
	_ret(0),
	_returnPath(""),
	_uploadPath(""),
	_CGIPath(""),
	_CGIExt("py"),
	_indexFiles(0),
	_lParsed(0)
{
	memset(_errParsed, 0, sizeof(_errParsed));
	_errList.insert (std::pair<int,std::string>(204, "Networking/HTML/Errors/204.html"));
	_errList.insert (std::pair<int,std::string>(201, "Networking/HTML/Errors/201.html"));
	_errList.insert (std::pair<int,std::string>(400, "Networking/HTML/Errors/400.html"));
	_errList.insert (std::pair<int,std::string>(403, "Networking/HTML/Errors/403.html"));
	_errList.insert (std::pair<int,std::string>(404, "Networking/HTML/Errors/404.html"));
	_errList.insert (std::pair<int,std::string>(405, "Networking/HTML/Errors/405.html"));
	_errList.insert (std::pair<int,std::string>(409, "Networking/HTML/Errors/409.html"));
	_errList.insert (std::pair<int,std::string>(500, "Networking/HTML/Errors/500.html"));
	_errList.insert (std::pair<int,std::string>(503, "Networking/HTML/Errors/503.html"));
}

Location::~Location()
{
}

Location::Location(const Location &copy)
{
	operator=(copy);
}

Location	&Location::operator=(const Location &copy)
{
	if (this != &copy)
	{
		_location = copy._location;
		_root = copy._root;
		_clientMaxBodySize = copy._clientMaxBodySize;
		_methods = copy._methods;
		_isGet = copy._isGet;
		_isPost = copy._isPost;
		_isDelete = copy._isDelete;
		_isPut = copy._isPut;
		_autoIndex = copy._autoIndex;
		_ret = copy._ret;
		_returnPath = copy._returnPath;
		_uploadPath = copy._uploadPath;
		_CGIPath = copy._CGIPath;
		_CGIExt = copy._CGIExt;
		if (!_indexFiles.empty())
			_indexFiles.clear();
		if (!copy._indexFiles.empty())
			_indexFiles = std::vector<std::string>(copy._indexFiles);
		_lParsed = 0;
		memset(_errParsed, 0, sizeof(_errParsed));
		_errList = copy._errList;
	}
	return *this;
}

void	Location::setLocation(const std::string location)
{
	_location = location;
	_lParsed += 1;
}

int Location::setRoot(const std::string root)
{
	if (_lParsed & 2)
		return 66;
	_root = root;
	_lParsed += 2;
	return 0;
}

int	Location::setClientMaxBodySize(size_t bodySize)
{
	if (_lParsed & 1 << 2)
		return 66;
	_clientMaxBodySize = bodySize;
	_lParsed += 4;
	return 0;
}

int	Location::setMethods(int method)
{
	int	diff = 0;
	if (_lParsed & 1 << 3)
		return 66;
	diff = method ^ _methods;
	_methods = method;
	/*	_isGet = diff & 1 ? method & 1 : _isGet; */
	_isPost = diff & 2 ? method & 2 : _isPost;
	_isDelete = diff & 4 ? method & 4 : _isDelete;
	_isPut = diff & 8 ? method & 8 : _isPut;
	_lParsed += 8;
	return 0;
}

int	Location::setAutoIndex(const bool autoindex)
{
	if (_lParsed & 1 << 4)
		return 66;
	_autoIndex = autoindex;
	_lParsed += 1 << 4;
	return 0;
}

int Location::setReturnType(int returntype)
{
	if (_lParsed & 1 << 5)
		return 66;
	_ret = returntype;
	_lParsed += 1 << 5;
	return 0;
}

int	Location::setReturnPath(const std::string path)
{
	if (_lParsed & 1 << 10)
		return 66;
	_returnPath = path;
	_lParsed += 1 << 10;
	return 0;
}

int	Location::setUploadPath(const std::string path)
{
	if (_lParsed & 1 << 9)
		return 66;
	_uploadPath = path;
	_lParsed += 1 << 9;
	return 0;
}

int	Location::setCGIPath(const std::string path)
{
	if (_lParsed & 1 << 6)
		return 66;
	_CGIPath = path;
	_lParsed += 1 << 6;
	return 0;
}

int	Location::setCGIExt(const std::string extension)
{
	if (_lParsed & 1 << 7)
		return 66;
	_CGIExt = extension;
	_lParsed += 1 << 7;
	return 0;
}

int	Location::setIndexFiles(const std::deque<std::string> files, size_t *i)
{
	if (_lParsed & 1 << 8)
		return 66;
	if (!_indexFiles.empty())
		_indexFiles.clear();
	while (*i < files.size())
	{
		for (size_t n = 0; n < _indexFiles.size(); n++)
			if (_indexFiles[n] == files[*i])
				return 66;
		try
		{
			_indexFiles.push_back(files[(*i)++]);
		}
		catch(const std::exception& e)
		{
			return 68;
		}
		
	}
	_lParsed += 1 << 8;
	return 0;
}

int	Location::setErrorList(const int errCode, const std::string filePath)
{
	for (unsigned i = 0; i < (sizeof(_errParsed) / sizeof(int)); i++)
	{
		if (_errParsed[i] == errCode)
			return 66;
		if (_errParsed[i] == 0)
		{
			_errParsed[i] = errCode;
			break;
		}
	}
	errMap::const_iterator it = _errList.find(errCode);
	if (it == _errList.end())
		return 67;
	_errList[errCode] = filePath;
	return 0;
}

std::string	Location::getLocation() const
{
	return _location;
}

std::string	Location::getRoot() const
{
	return _root;
}

int	Location::getClientMaxBodySize() const
{
	return _clientMaxBodySize;
}

bool Location::getAutoIndex() const
{
	return _autoIndex;
}

bool Location::isMatchWithUri(std::string requestUri)
{
	if (requestUri.rfind(_location, 0) == 0)
		return true;
	return false;
}

bool Location::isGet() const
{
	return _isGet;
}

bool Location::isPost() const
{
	return _isPost;
}

bool Location::isDelete() const
{
	return _isDelete;
}

bool Location::isPut() const
{
    return _isPut;
}

int	Location::getReturn() const
{
	return _ret;
}

std::string Location::getReturnPath() const
{
	return _returnPath;
}

std::string Location::getUploadPath() const
{
	return _uploadPath;
}

std::string Location::getCGIPath() const
{
	return _CGIPath;
}

std::string Location::getCGIExt() const
{
    return _CGIExt;
}

std::vector<std::string> Location::getIndexFiles() const
{
	return _indexFiles;
}

errMap Location::getErrorList() const
{
	return _errList;
}

void	Location::getAll(std::string color) const
{
	std::cout << color << ":\t\t" << "\"" << getLocation() << "\"" << std::endl;
	std::cout << "\tRoot:\t\t" << "\"" << getRoot() << "\"" << std::endl;
	std::cout << "\tClientBodySize:\t" << getClientMaxBodySize() << std::endl;
	std::cout << "\tIs GET:\t    " << isGet() << std::endl;
	std::cout << "\tIs POST:\t" << isPost() << std::endl;
	std::cout << "\tIs DELETE:\t" << isDelete() << std::endl;
	std::cout << "\tIs PUT:\t\t" << isPut() << std::endl;
	std::cout << "\tAutoIndex:\t" << (getAutoIndex() ? "On" : "Off") << std::endl;
	std::cout << "\tReturn:\t\t" << getReturn() << "\t" << getReturnPath() << std::endl;
	std::cout << "\tUpload:\t\t" << "\"" << getUploadPath() << "\"" << std::endl;
	std::cout << "\tCGI Path:\t" << "\"" << getCGIPath() << "\"" << std::endl;
	std::cout << "\tCGI Ext:\t" << getCGIExt() << std::endl;
	std::cout << "\tIndex Files:\t" << RESET << std::endl;
	for (size_t n = 0; n < _indexFiles.size(); n++)
		std::cout << color << "\t\t\t" << getIndexFiles()[n] << RESET << std::endl;
	std::cout << color << "\tError files:\t" << RESET << std::endl;
	for (errMap::const_iterator it = _errList.begin(); it != _errList.end(); it++)
		std::cout << color << "\t\t" << it->first << "\t" << it->second << RESET << std::endl;
}

int Location::getReturn() {
	return 301;
}
