
//
// Created by Brittni Ashleigh on 9/10/21.
//

#include "BasicMethod.hpp"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#define BUFFER_SIZE 32768

#define CGI_EXT "py"

BasicMethod::BasicMethod(Client *client) {
	statusCodesMap.insert (std::pair< int,std::string>(200, "OK"));
	statusCodesMap.insert (std::pair< int,std::string>(201, "Created"));
	statusCodesMap.insert (std::pair< int,std::string>(204, "No content"));
	statusCodesMap.insert (std::pair< int,std::string>(301, "Moved Permanently"));
	statusCodesMap.insert (std::pair< int,std::string>(400, "Bad Request"));
	statusCodesMap.insert (std::pair< int,std::string>(403, "Forbidden"));
	statusCodesMap.insert (std::pair< int,std::string>(404, "Not Found"));
	statusCodesMap.insert (std::pair< int,std::string>(405, "Method Not Allowed"));
	statusCodesMap.insert (std::pair< int,std::string>(413, "Request Entity Too Large"));
	statusCodesMap.insert (std::pair< int,std::string>(500, "Internal Server Error"));
	statusCodesMap.insert (std::pair< int,std::string>(501, "Not Implemented"));
	statusCodesMap.insert (std::pair< int,std::string>(502, "Bad Gateway"));
	statusCodesMap.insert (std::pair< int,std::string>(505, "HTTP Version Not Supported"));

	this->client = client;
	isCGI = false;
}

std::string BasicMethod::_getFullRequestedPath(Location* location) {
	char	currentDir[MAXPATHLEN];
	getcwd(currentDir, MAXPATHLEN);

	std::string myCurrentDir(currentDir);
	fullRequestedPath = location->getRoot();
	if (fullRequestedPath == "")
		fullRequestedPath = myCurrentDir;
	std::string tmp = client->_requestHeader["URI"].substr(location->getLocation().length());
	fullRequestedPath = (fullRequestedPath.back() == '/') || tmp[0] == '/' ?
			fullRequestedPath : fullRequestedPath + "/";
	fullRequestedPath += tmp;
	return fullRequestedPath;
}

void BasicMethod::_makeResponse() {
	if (client->isErrorHappened())
		client->writeErrorToBody();
	else
	{
		_makeResponseBody();
		if (client->isErrorHappened())
			client->writeErrorToBody();
	}
	if (!isCGI)
	{
		client->makeResponseHeader();
	}
	if (isCGI)
	{
		std::cout << "Processing a cgi request...\n" << std::endl;
		client->makeResponseHeader();
	}
	client->combineResponseParts();
	std::string head = client->responseHeader.str();
	std::cout << BLUE << "____________________\n" <<"RESPONSE HEADER: \n"<< "____________________\n" << head << SHALLOW << std::endl;
	std::cout << "_________________________________________________________________________________________________" << std::endl;
}

bool BasicMethod::uriIsFile(std::string path) {
	if (isThereSuchFile(path))
	{
		std::string ext = getFileExtension(path);
		if (ext == client->location->getCGIExt())
			_cgi(path);
		else
			client->setFileToSend(path);
		return true;
	}
	return false;
}

//add char env to vector of envs
void BasicMethod::addEnvToVector(std::string fullName) {
	vectorOfEnvs.push_back(fullName);
}

//add every env to environment variables
void BasicMethod::addEnv() {
	for (std::vector<std::string>::iterator it = vectorOfEnvs.begin() ; it != vectorOfEnvs.end(); ++it)
	{
		if(putenv(const_cast< char * >(it->c_str())) == -1)
		{
			std::cout << RED << "putenv failed \n" << std::endl;
			return;
		}
	}
}

void BasicMethod::printEnvForCgi(char *key)
{
	char* pPath;
	pPath = getenv (key);
	if (pPath!=NULL)
		std::cout << GREEN << "The current "<< key << " is: " << pPath << SHALLOW << std::endl;
	else
		std::cout << RED << "The isn't "<< key << " :( " << SHALLOW << std::endl;
}

void  BasicMethod::printAllExistingEnvForCgi()
{
	std::cout << GREEN << "__ENVIRONMENTS:___________________________________________________________________________________" << SHALLOW << std::endl;
	// check if some environments really exist
	printEnvForCgi((char *) "CONTENT_LENGTH");
	printEnvForCgi((char *) "CONTENT_TYPE");
	printEnvForCgi((char *) "GATEWAY_INTERFACE");
	printEnvForCgi((char *) "SERVER_NAME");
	printEnvForCgi((char *) "SERVER_PORT");
	printEnvForCgi((char *) "SERVER_ADDR");
	printEnvForCgi((char *) "PATH_INFO");
	printEnvForCgi((char *) "SERVER_PROTOCOL");
	printEnvForCgi((char *) "PATH_TRANSLATED");
	printEnvForCgi((char *) "REQUEST_METHOD");
	printEnvForCgi((char *) "REDIRECT_STATUS");
	printEnvForCgi((char *) "HTTP_HOST");
	printEnvForCgi((char *) "HTTP_USER_AGENT");
	std::cout << GREEN << "_________________________________________________________________________________________________" << SHALLOW << std::endl;
}

//char *BasicMethod::strToupper(std::string name)
//{
//    //TODO
//	char *cToStr = new char[name.size() + 1];
//	strcpy(cToStr, name.c_str());
//	int i = 0;
//	while (cToStr[i])
//	{
//		cToStr[i]=toupper(cToStr[i]);
//		if(cToStr[i] == '-')
//			cToStr[i] = '_';
//		i++;
//	}
//    return cToStr;
//}

std::string BasicMethod::strToupper(std::string name)
{
    char *cToStr = new char[name.size() + 1];
    strcpy(cToStr, name.c_str());
    int i = 0;
    while (cToStr[i])
    {
        cToStr[i]=toupper(cToStr[i]);
        if(cToStr[i] == '-')
            cToStr[i] = '_';
        i++;
    }
    std::string answer(cToStr);
    delete [] cToStr;
    return answer;
}


void  BasicMethod::makeAllEnvForCgi(std::string &file)
{
	if(!client->_requestHeader["content-length"].empty())
		addEnvToVector("CONTENT_LENGTH="  + client->_requestHeader["content-length"]);
	if(!client->_requestHeader["Content-Length"].empty())
		addEnvToVector("CONTENT_LENGTH="  + client->_requestHeader["Content-Length"]);
	if (client->isChunked())
	{
		int len = client->_requestBody.length();
		std::stringstream ss;
		ss << len;
		std::string strlen = ss.str();
		addEnvToVector("CONTENT_LENGTH="  + strlen);
	}
	if(!client->_requestHeader["content-type"].empty())
		addEnvToVector("CONTENT_TYPE="  + client->_requestHeader["content-type"]);
	if(!client->_requestHeader["Content-Type"].empty())
		addEnvToVector("CONTENT_TYPE="  + client->_requestHeader["Content-Type"]);
	addEnvToVector("GATEWAY_INTERFACE=CGI/1.1");
	addEnvToVector("SERVER_NAME=" + client->siteConf->getServerName());
	addEnvToVector("SERVER_PORT=" + std::to_string(client->siteConf->getPort()));
	addEnvToVector("SERVER_ADDR=" + client->siteConf->getListen());
	addEnvToVector("PATH_INFO="+file);
	addEnvToVector("SERVER_PROTOCOL=" + client->_requestHeader["Protocol"]);
	addEnvToVector("PATH_TRANSLATED=" + file);
	addEnvToVector("REQUEST_METHOD="  + client->_requestHeader["Method"]);
	addEnvToVector("REDIRECT_STATUS=200");

	for (std::map<std::string, std::string>::iterator iterat=client->_requestHeader.begin(); iterat!=client->_requestHeader.end(); ++iterat)
	{
		std::string partOfName = strToupper(iterat->first);
		std::string fullName("HTTP_" + partOfName + "=" + iterat->second);
		addEnvToVector(fullName);
	}
}

void BasicMethod::_cgi(std::string &file) {

	makeAllEnvForCgi(file);
	addEnv();
	printAllExistingEnvForCgi();

	std::stringstream cgi;
	cgi << client->location->getCGIPath() << " < " << file << " > cgi_raw_result";
	std::string command = cgi.str();
	int result = system(cgi.str().c_str());
	if (result == 0)
	{
		isCGI = true;
		std::ifstream ifs("cgi_raw_result");
		std::string rawCgi;
		getline (ifs, rawCgi, (char) ifs.eof());
		std::ifstream la("cgi_raw_result");
		std::string _requestBody;
		int headerEndPosition = rawCgi.find(EMPTY_LINE);
		_requestBody = rawCgi.substr(headerEndPosition + 4,
									 rawCgi.length() - (headerEndPosition + 4));
		std::ofstream out("cgi_result");
		out << _requestBody;
		out.close();

		client->responseBody.str() = _requestBody;
		std::ifstream cgi_result(file);
		if (cgi_result)
		{
			client->setFileToSend("cgi_result");
		}
		else
			client->setStatusCode(500);
	}
	else
	{
		isCGI = false;
		client->setStatusCode(500);
		client->writeErrorToBody();
	}

}
