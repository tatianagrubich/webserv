
//
// Created by Brittni Ashleigh on 9/16/21.
//

#ifndef UNTITLED_CLIENT_HPP
#define UNTITLED_CLIENT_HPP
#include <string>
#include "map"
#include "../../Parser/Site.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <sstream>
#include <algorithm>
#define BLUE "\033[1;34m"
#define RED "\033[1;31m"
#define YELLOW "\033[0;33m"
#define SHALLOW "\033[0m"
#define BGBLUE "\033[44m"
#include <poll.h>
#include "../../Utils/Utils.hpp"

class Client {
private:
    int _sd;
	std::map<int, Site*> socketConfigMap;
	int statusCode;
	bool _isHeaderHandled;
	std::ifstream _fileToSend;
	bool _needToRemove;

    struct pollfd *pollConf;
    bool _isBodyHandled;
	std::string trim(std::string s);
	std::string ltrim(std::string s, const char* t);
	std::string rtrim(std::string s, const char* t);
    void _cutResponse(int start);
    std::vector<char> finalResponse;
    int _responseContentLen;
    std::string _responseContentType;


public:
    Client();


public:
	void autoindex(std::string fullRequestedPath);
    Location *location;

	std::map <std::string, std::string> _requestHeader;
	std::map <std::string, std::string>::iterator _request_header_it;
    std::string _requestBody;
    std::stringstream responseHeader;
    std::stringstream responseBody;

    void _retrieveHeader();
    void _retrieveSolidBody();
	std::vector<Site *> siteConfsVector;
	Site * siteConf;
	std::string rawRequest;
	Client(int sd);
    void setPollConf(pollfd *pollConf);
    int getResponseContentLen();
	void parseHeader(std::string);
	void setIsHeaderHandled(bool isHeaderHandled);
	void setIsBodyHandled(bool isBodyHandled);
	bool getIsHeaderHandled() const;
	bool getIsBodyHandled() const;
	int	getSd();
	void setStatusCode(int statusCode);
	void reset();
	std::string checkForSpace(std::string str);
	std::string trimStr(std::string toTrim);
	void headerValidation();
	int getStatusCode();
	bool isErrorHappened();

	void setSiteConf(std::vector<Site *> siteConfsVector);


    void setEvents(short flags);

    void sendResponse();

    bool haveDataToSend();

    void setNeedToRemove(bool b);

    bool isNeedToRemove();

	void appendRequestPart(std::string & requestPart);
	void appendResponseBody(std::string responseBodyPart);
	void appendResponseBody(std::stringstream & responseBodyPart);
	void appendResponseBody(std::ifstream & responseBodyPart);
	void appendResponseHeader(std::string responseHeaderPart);
	void setFileToSend(std::string fileToSend);

	void combineResponseParts();
	void writeErrorToBody();
	void makeResponseHeader();


	std::string getResponseContentType();

	void _retrieveChunkedBody();

	bool isChunked();

	Location *chooseLocation();

	Site* chooseSiteConf(std::vector<Site *>);
};


#endif //UNTITLED_CLIENT_HPP
