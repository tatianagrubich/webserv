
//
// Created by Brittni Ashleigh on 9/16/21.
//

#include "Delete.hpp"

Delete::Delete(Client *client) : BasicMethod(client) {
	_makeResponse();
}

void Delete::_makeResponseBody() {

	std::string fullRequestedPath = _getFullRequestedPath(client->location);
	std::cout << RED << "FULL REQ PATH: " << fullRequestedPath << SHALLOW << std::endl;
	//Если файл существует, то мы его удаляем
	if (isThereSuchFile(fullRequestedPath))
	{
		std::cout << "it is exists" << std::endl;
		if( remove(fullRequestedPath.c_str()) != 0 )
			perror( "Error deleting file" );
		else
		{
			puts( "File successfully deleted" );
			client->setStatusCode(204);
			client->writeErrorToBody();
			return;
		}
		if (client->isErrorHappened())
			client->writeErrorToBody();
	}
}

void Delete::_handling() {
}
