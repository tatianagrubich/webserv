#include "Parser/ConfigParser.hpp"
#include "Networking/Server/Server.hpp"


int main() {
	std::string filename = "default.conf";
	std::ifstream	fs(filename);

	if (!fs.is_open())
	{
		std::cerr << "Error: Can't open " << filename << " file" << std::endl;
		return 1;
	}
	ConfigParser *cnf = new ConfigParser(fs);
	cnf->parser();
	fs.close();
	std::vector<Site*> sites = cnf->getWSConfigs();
	delete cnf;
	for (size_t i = 0; i < sites.size(); i++)
		sites[i]->getAll(i);
	 Server server(sites);
	 server.launch();
}
