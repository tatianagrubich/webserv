
//
// Created by Brittni Ashleigh on 9/3/21.
//

#include "SimpleSocket.hpp"

SimpleSocket::SimpleSocket(int domain, int service, int protocol,
						   int port, u_long interface) {
	// Define address structure
	on = 1;
	addres.sin_family = domain;
	addres.sin_port = htons(port);



	addres.sin_addr.s_addr = interface;
	// Establish listeningSocket
	sock_fd = socket(domain, service, protocol);
	test_connection(sock_fd);
	rc = setsockopt(sock_fd, SOL_SOCKET,  SO_REUSEADDR,
					(char *)&on, sizeof(on));
	test_operation(rc);
	rc = ioctl(sock_fd, FIONBIO, (char *)&on);
	test_operation(rc);
}

void SimpleSocket::test_connection(int item_to_test) {
	if (item_to_test < 0) {
		perror("listeningSocket() failed ...");
		exit(EXIT_FAILURE);
	}
}



struct sockaddr_in SimpleSocket::get_address() {
	return addres;
}

int SimpleSocket::get_connection() {
	return connection;
}

int SimpleSocket::getSD() {
	return sock_fd;
}

//Setters

void SimpleSocket::set_connection(int con) {
	connection = con;
}

void SimpleSocket::test_operation(int rc) {
	if (rc < 0)
	{
		perror("Error:");
		close(sock_fd);
		exit(EXIT_FAILURE);
	}
}
