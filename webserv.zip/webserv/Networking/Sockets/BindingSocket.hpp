
//
// Created by Brittni Ashleigh on 9/4/21.
//

#ifndef UNTITLED_BINDINGSOCKET_HPP
#define UNTITLED_BINDINGSOCKET_HPP
#include "SimpleSocket.hpp"

class BindingSocket : public SimpleSocket {
private:
public:
	BindingSocket(int domain, int service, int protocol,
				  int port, u_long interface);

	int connect_to_network(int sock, struct sockaddr_in address);
};


#endif //UNTITLED_BINDINGSOCKET_HPP
