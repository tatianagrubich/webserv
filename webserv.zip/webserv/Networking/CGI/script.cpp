#! /usr/bin/
//Для компиляции кода на C++ необходимо установить библиотеку cgicc
sudo apt-get install libcgicc5-dev
//Пример компиляции:
g++ -o 3.get.post.cgi 3.get.post.cpp -lcgicc
