
//
// Created by Brittni Ashleigh on 9/15/21.
//

#ifndef UNTITLED_MIMETYPES_HPP
#define UNTITLED_MIMETYPES_HPP
#include <map>
#include "string"
class MimeTypes {
private:
	std::map<std::string, std::string> _extensionTypeMap;
	std::map<std::string, std::string> _typeExtensionMap;
public:
	MimeTypes();
	std::string getTypeByExtension(std::string);
	std::string getExtensionByType(std::string);
};


#endif //UNTITLED_MIMETYPES_HPP
