
//
// Created by Brittni Ashleigh on 9/3/21.
//

#ifndef UNTITLED_SIMPLESOCKET_HPP
#define UNTITLED_SIMPLESOCKET_HPP
#include "iostream"
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <errno.h>
#include <arpa/inet.h>
#include <unistd.h>

class SimpleSocket {
private:
	struct sockaddr_in addres;
	int sock_fd;
	int on;
	int rc;
	int connection;
public:
	SimpleSocket(int domain, int service, int protocol,
				 int port, u_long interface);
	int virtual connect_to_network(int sock, struct sockaddr_in address) = 0;
	void test_connection(int);
	void test_operation(int);
	struct sockaddr_in get_address();
	int getSD();
	int get_connection();

	//Setters
	void set_connection(int);
};


#endif //UNTITLED_SIMPLESOCKET_HPP
