# if env['HTTP_METHOD'] == 'POST':
#     if env['HTTP_CONTENT_TYPE'] == 'plain/text':
#
# elif env['HTTP_METHOD'] == 'GET':
import cgi

# form = cgi.FieldStorage()
# text1 = form.getfirst("TEXT_1", "не задано")
# text2 = form.getfirst("TEXT_2", "не задано")


body = ''
body += """<!DOCTYPE HTML>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Обработка данных форм</title>
        </head>
        <body>"""

body += "<h1>Обработка данных форм!</h1>"
# body += "<p>TEXT_1: {}</p>".format(text1)
# body += "<p>TEXT_2: {}</p>".format(text2)

body += """</body>
        </html>"""

print(f"HTTP/1.1 200")
print(f"Content-Length: {len(body) + 1}")
print("Content-type: text/html\r\n\r")
print(body)
